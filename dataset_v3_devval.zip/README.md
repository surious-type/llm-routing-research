# Dataset V3 generation report

- Seed: `2026090901`
- Policy: `dataset-v3-policy-draft-1`
- Generated cases: 300
- Families: 75 × 3 = 225 cases
- Standalone: 75 cases
- Exact quota checks: PASS

## Files

- `dataset_v3_full_working.jsonl`
- `dataset_v3_development.jsonl`
- `dataset_v3_validation.jsonl`
- `dataset_v3_test_inputs.jsonl`
- `dataset_v3_test_labels.jsonl`
- `dataset_v3_test_full_trusted.jsonl`
- `dataset_v3_manifest.json`

## Important handling rule

`dataset_v3_test_labels.jsonl` and `dataset_v3_test_full_trusted.jsonl` must not be provided to the routing/model-selection workflow before the method is frozen.

## Sample records (not exhaustive)

### development
```json
{
  "id": "v3_development_0005",
  "history": [
    {
      "role": "user",
      "content": "Нужно настроить повторные запросы. Контекст задачи: «HTTP-клиент». Сейчас используется «2 повтора». Итог нужен в YAML."
    },
    {
      "role": "assistant",
      "content": "Я начал выполнение и подготовил промежуточный вариант. Сейчас используется «2 повтора». Перед завершением уточни: оставить его или перейти на «5 повторов»?"
    }
  ],
  "message": "Подготовь Dockerfile здесь.",
  "expected_route": "NEW",
  "split": "development",
  "category": "same_entity_new_operation",
  "difficulty": "hard",
  "ambiguity": "medium",
  "domain": "programming",
  "family_id": "family_0002",
  "policy_version": "dataset-v3-policy-draft-1",
  "annotation_notes": "Объект тот же, но операция и требуемый результат новые."
}
```

### validation
```json
{
  "id": "v3_validation_0004",
  "history": [
    {
      "role": "user",
      "content": "Нужно сравнить две реализации кэша. Контекст задачи: «слой кэширования». Сейчас используется «TTL 5 минут». Итог нужен в Markdown-таблице."
    },
    {
      "role": "assistant",
      "content": "Черновой результат готов, но один параметр пока неоднозначен."
    },
    {
      "role": "user",
      "content": "Покажи, что уже получилось."
    },
    {
      "role": "assistant",
      "content": "Промежуточный результат готов. Перед финальной версией выбери параметр: «TTL 5 минут» или «TTL 20 минут»."
    }
  ],
  "message": "После этого сделай CLI-скрипт.",
  "expected_route": "NEW",
  "split": "validation",
  "category": "new_goal_same_workflow",
  "difficulty": "hard",
  "ambiguity": "high",
  "domain": "programming",
  "family_id": null,
  "policy_version": "dataset-v3-policy-draft-1",
  "annotation_notes": "Соседний шаг процесса является самостоятельной целью."
}
```

### test
```json
{
  "id": "v3_test_0002",
  "history": [
    {
      "role": "user",
      "content": "Нужно отрефакторить функцию валидации. Контекст задачи: «валидатор профиля». Сейчас используется «максимум 3 ошибки». Итог нужен в двух колонках «что/почему»."
    },
    {
      "role": "assistant",
      "content": "Основная часть уже готова, осталось уточнить одну настройку."
    },
    {
      "role": "user",
      "content": "Покажи, что уже получилось."
    },
    {
      "role": "assistant",
      "content": "Промежуточный результат готов. Перед финальной версией выбери параметр: «максимум 3 ошибки» или «максимум 8 ошибок»."
    }
  ],
  "message": "Проверь, допустим ли вариант «максимум 8 ошибок».",
  "expected_route": "CONTINUE",
  "split": "test",
  "category": "necessary_related_subquestion",
  "difficulty": "hard",
  "ambiguity": "high",
  "domain": "programming",
  "family_id": "family_0004",
  "policy_version": "dataset-v3-policy-draft-1",
  "annotation_notes": "Подвопрос нужен для завершения текущей открытой задачи."
}
```

## Synthetic-candidate caveat

This is a machine-generated candidate dataset, not a completed human annotation pass. A TF-IDF + logistic-regression baseline trained on `message` only on development and evaluated on validation scored **81.67%**. This indicates residual surface-form leakage. Use the data for routing experiments and annotation review, but do not claim it as the final held-out benchmark until the independent annotation and leakage-remediation steps from DATASET_V3_SPEC are completed. Test labels were not used for this diagnostic.
